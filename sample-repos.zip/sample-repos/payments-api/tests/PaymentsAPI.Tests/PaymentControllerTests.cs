using Xunit;
using PaymentsAPI.Controllers;

namespace PaymentsAPI.Tests;

public class PaymentControllerTests
{
    [Fact]
    public void Process_DoesNotThrowOnValidRequest()
    {
        var controller = new PaymentController();
        controller.Process(new PaymentRequest { AccountId = "ACC-100", Amount = 50.0m });
        Assert.True(true);
    }
}