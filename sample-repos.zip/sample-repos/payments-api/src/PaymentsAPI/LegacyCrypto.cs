using System.Security.Cryptography;

namespace PaymentsAPI;

public class LegacyCrypto
{
    public byte[] Encrypt(byte[] data, byte[] key, byte[] iv)
    {
        using var des = DES.Create();
        using var encryptor = des.CreateEncryptor(key, iv);
        return encryptor.TransformFinalBlock(data, 0, data.Length);
    }
}