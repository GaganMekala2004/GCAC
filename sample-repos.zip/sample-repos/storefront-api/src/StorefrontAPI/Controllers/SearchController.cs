namespace StorefrontAPI.Controllers;

public class SearchController
{
    public string Search(string q)
    {
        return $"<html><body><h1>Search results for {q}</h1></body></html>";
    }
}