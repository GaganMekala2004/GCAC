# Identity Provider Infrastructure
Configuration for Ivanti Connect Secure gateway appliances.