using Newtonsoft.Json;

namespace InventoryManager;

public class ItemService
{
    public string SerializeItem(object item)
    {
        return JsonConvert.SerializeObject(item);
    }
}