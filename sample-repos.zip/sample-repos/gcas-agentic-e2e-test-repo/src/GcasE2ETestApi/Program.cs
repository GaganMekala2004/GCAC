using GcasE2ETestApi;
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddSingleton<SecretService>();

var app = builder.Build();

app.MapControllers();
app.Run();

public partial class Program { }
