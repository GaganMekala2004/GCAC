package com.example.customer.controller;

import java.io.File;

public class DocumentDownloadController {
    public File downloadFile(String filename) {
        File file = new File("/var/data/docs/" + filename);
        return file;
    }
}